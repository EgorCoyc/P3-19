import asyncio
import requests

IAM_TOKEN = 't1.9euelZrLyZ2VlM-XxsuJzomVy4ydkO3rnpWansyKlJuUnIzOlpCNicyMy4rl8_ctKx1r-e9KBhpy_d3z921ZGmv570oGGnL9.gd5O2bYad1cqlF3Nx0nBD4-lIf_PhY1tzjaHLv5SoWyVdXeTTftD5CiExqiXyaOQnW1D1N8TG3U3s824lKkDDA'
folder_id = 'b1gjs760pclkol3mppdg'
target_language = 'ru'
texts = str(input())

body = {
    "targetLanguageCode": target_language,
    "texts": texts,
    "folderId": folder_id,
}

headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer {0}".format(IAM_TOKEN)
}


async def perevod():
    response = requests.post('https://translate.api.cloud.yandex.net/translate/v2/translate',
                             json=body,
                             headers=headers
                             )

    print(response.text)


asyncio.run(perevod())
