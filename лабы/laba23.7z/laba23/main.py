import requests
import httplib2
import urllib3

response = requests.post("https://vk.com/", json={"example":"foobar"})
print(response.status_code)

h = httplib2.Http(".cache")
(response, content) = h.request("https://vk.com/", "POST")
print(response.status)

response = urllib3.PoolManager().request("GET", "https://vk.com/")
print(response.status)
