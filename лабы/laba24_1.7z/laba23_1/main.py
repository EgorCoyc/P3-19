import requests
import httplib2
import urllib3

# Request Во-первых, он поддерживает полностью спокойный API
# Независимо от того, GET / POST, вам никогда не придется снова кодировать параметры

response = requests.post("https://vk.com/", json={"example": "foobar"})
print(response.status_code)

# обрабатывает http-запросы, это то, что происходит за кулисами, когда вы открываете URL.

h = httplib2.Http(".cache")
(response, content) = h.request("https://vk.com/", "POST")
print(response.status)

# обрабатывает открытие и чтение URL-адресов. Он также обрабатывает дополнительные вещи, такие как хранение файлов cookie.

response = urllib3.PoolManager().request("GET", "https://vk.com/")
print(response.status)
