from abc import ABC

ABSTRACT_METHOD = lambda: print("This is abstract method")


class Abstract:
    def __init__(self):
        for member in dir(type(self)):
            if getattr(type(self), member) == ABSTRACT_METHOD:
                raise Exception("Can't instantiate the abstract class")


def abstract_method(method):
    return ABSTRACT_METHOD


class Ovaria(Abstract):
    @abstract_method
    def kill(self):
        pass


class Drive(Abstract):
    @abstract_method
    def move(self):
        pass


class Pig(Drive, Ovaria):
    def kill(self):
        print("Разбился")

    def move(self):
        print("Я вожу машину")


try:
    Ovaria()
except Exception as error:
    print(error)


class BaseA:
    def method_a(self):
        print("method_a от BaseA")

    def method_b(self):
        print("method_b от BaseA")


class BaseB:
    def method_a(self):
        print("method_a от BaseB")

    def method_c(self):
        print("method_c от BaseB")


class NotBase(BaseA, BaseB):
    def method_a(self):
        print("method_a от NotBase")
        super(NotBase, self).method_a()
        BaseB.method_a(self)
        return self

    def method_b(self):
        print("method_b от NotBase")
        super(NotBase, self).method_b()
        return self

    def method_c(self):
        print("method_c от NotBase")
        BaseB.method_c(self)
        return self


class Car(Ovaria, Drive):
    def kill(self):
        print("Вы разбились")

    def move(self):
        print("Я вожу машину")
        print(f"Завод на котором собиралась данная машина {type(self).__mro__}")

try:
    Ovaria()
except Exception as error:
    print(error)

car = Car()
car.move()
car.kill()
