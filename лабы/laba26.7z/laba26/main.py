import requests
import json

url = 'https://randomuser.me/api/'

response = requests.get(url)
print(response.text)
print(requests.get)
print(response.headers)
print(response.url)
print(response.status_code)

json_response = response.json()
print(json_response)

with open("file.json", "w") as s:
    json.dump(json_response, s)
