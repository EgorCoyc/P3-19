from Package import *


def most_frequent(List):
    return max(set(List), key=List.count)


item = List.pop(most_frequent(List))
print(item)
print(List)
print(most_frequent(List))

print(setA)
print(setB)

print("пересечение множеств:")
print(setA & setB)

print("Объединение множеств:")
print(setA | setB)

print("Вычитание множеств:")
print(setB - setA)

print("Сравнения множеств:")
print(setA == setB)
