class Vehicle:

    def __init__(self, color, doors, tires, vtype):
        self.color = color
        self.doors = doors
        self.tires = tires
        self.vtype = vtype

    def brake(self):
        return "%s braking" % self.vtype

    def drive(self):
        return "I'm driving a %s %s!" % (self.color, self.vtype)


if __name__ == "__main__":
    car = Vehicle("blue", 5, 4, "car")
    print(car.brake())
    print(car.drive())

    truck = Vehicle("red", 3, 6, "truck")
    print(truck.drive())
    print(truck.brake())

print("-----------------")


class Rectangle:

    def __init__(self, width, height):
        self.width = width
        self.height = height

    def getW(self):
        return self.width

    def getH(self):
        return self.height

    def getA(self):
        return self.width * self.height


r1 = Rectangle(10, 5)
r2 = Rectangle(20, 11)

print("r1.width = ", r1.width)
print("r1.height = ", r1.height)
print("r1.getWidth() = ", r1.getW())
print("r1.getArea() = ", r1.getA())

print("-----------------")

print("r2.width = ", r2.width)
print("r2.height = ", r2.height)
print("r2.getWidth() = ", r2.getW())
print("r2.getArea() = ", r2.getA())
