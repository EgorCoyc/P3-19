import random

# Список чисел
seq = [10, 11, 12, 13, 14, 15]

# Вывод двух рандомных чисел
random_seq = random.sample(seq, 2)
print(random_seq)
